module.exports = {
    facebook: {
        clientID: '',
        clientSecret: ''
    },
    
    google: {
        clientID: '',
        clientSecret: ''
    }
}